'use client';

import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, CheckCircle2, Save, Trash2 } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import AdminSidebar from '@/app/components/AdminSidebar';
import ArticleMediaManager, { type ArticleImage, type ArticleVideo } from '@/app/components/ArticleMediaManager';
import ArticlePreviewPanel from '@/app/components/ArticlePreviewPanel';
import HtmlEditor from '@/app/components/HtmlEditor';
import { useArticles, type Article } from '@/app/hooks/useArticles';
import { useToast, ToastContainer } from '@/app/components/Toast';
import { useUsers } from '@/app/hooks/useUsers';
import { defaultManagedCategories, readManagedCategories, type ManagedCategory } from '@/app/lib/managedCategories';
import {
  canDeleteArticle,
  canEditArticle,
  canPublishArticle,
  canViewAllArticles,
  useCurrentAdminUser,
} from '@/app/lib/adminPermissions';

function stripHtml(content: string) {
  return content.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}

export default function EditArticlePage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { articles, updateArticle, deleteArticle, isLoaded } = useArticles();
  const { users } = useUsers();
  const { toasts, addToast, removeToast } = useToast();
  const currentUser = useCurrentAdminUser();
  const [drafts, setDrafts] = useState<Record<string, Article>>({});
  const brazilianLocations = [
    'Acre',
    'Alagoas',
    'Amapá',
    'Amazonas',
    'Bahia',
    'Ceará',
    'Distrito Federal',
    'Espírito Santo',
    'Goiás',
    'Maranhão',
    'Mato Grosso',
    'Mato Grosso do Sul',
    'Minas Gerais',
    'Pará',
    'Paraíba',
    'Paraná',
    'Pernambuco',
    'Piauí',
    'Rio de Janeiro',
    'Rio Grande do Norte',
    'Rio Grande do Sul',
    'Rondônia',
    'Roraima',
    'Santa Catarina',
    'São Paulo',
    'Sergipe',
    'Tocantins',
  ];
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [availableCategories, setAvailableCategories] = useState<ManagedCategory[]>(defaultManagedCategories);
  const [mediaState, setMediaState] = useState<{ images: ArticleImage[]; videos: ArticleVideo[]; primaryImage: string }>({
    images: [],
    videos: [],
    primaryImage: '',
  });

  const article = useMemo(() => articles.find((currentArticle) => currentArticle.id === params?.id), [articles, params?.id]);
  const formData = article ? drafts[article.id] ?? article : null;
  const categoryOptions = useMemo(() => {
    const options = [...availableCategories];
    if (formData?.category && !options.some((category) => category.slug === formData.category)) {
      options.push({
        id: Number.MAX_SAFE_INTEGER,
        name: formData.category,
        slug: formData.category,
        color: '#991B1B',
        articles: 0,
      });
    }
    return options;
  }, [availableCategories, formData?.category]);
  const canAccessArticle = Boolean(article && currentUser && canEditArticle(currentUser, article.author));

  const plainContent = useMemo(() => stripHtml(formData?.content ?? ''), [formData?.content]);
  const wordCount = plainContent.length > 0 ? plainContent.split(' ').length : 0;
  const readingTime = Math.max(1, Math.ceil(wordCount / 200));

  useEffect(() => {
    const syncCategories = () => {
      setAvailableCategories(readManagedCategories());
    };

    syncCategories();
    window.addEventListener('categoriesChanged', syncCategories);
    window.addEventListener('storage', syncCategories);

    return () => {
      window.removeEventListener('categoriesChanged', syncCategories);
      window.removeEventListener('storage', syncCategories);
    };
  }, []);

  useEffect(() => {
    if (article) {
      setMediaState({
        images: article.images ?? [],
        videos: article.videos ?? [],
        primaryImage: article.image ?? '',
      });
    }
  }, [article?.id]);

  const handleFieldChange = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    if (!formData) {
      return;
    }

    const { name, value, type } = event.target;
    const checked = type === 'checkbox' ? (event.target as HTMLInputElement).checked : undefined;

    setDrafts((current) => ({
      ...current,
      [formData.id]: {
        ...formData,
        [name]: type === 'checkbox' ? checked : value,
      },
    }));
  };

  const handleMediaChange = (images: ArticleImage[], videos: ArticleVideo[], primaryImage: string) => {
    setMediaState({ images, videos, primaryImage });
  };

  const handleSave = () => {
    if (!formData) {
      return;
    }
    if (formData.status === 'agendado' && (!formData.scheduledDate || !formData.scheduledTime)) {
      addToast('Defina data e horário para agendar a matéria.', 'error', 3000);
      return;
    }

    try {
      updateArticle(formData.id, {
        title: formData.title,
        subtitle: formData.subtitle,
        category: formData.category,
        excerpt: formData.excerpt || plainContent.slice(0, 180),
        content: formData.content,
        author: formData.author,
        image: mediaState.primaryImage,
        images: mediaState.images,
        videos: mediaState.videos,
        featured: formData.featured,
        location: formData.location,
        status: formData.status,
        scheduledDate: formData.scheduledDate,
        scheduledTime: formData.scheduledTime,
      });
    } catch (error) {
      addToast(error instanceof Error ? error.message : 'Sem permissão para salvar este artigo.', 'error', 3000);
      return;
    }

    setDrafts((current) => {
      const next = { ...current };
      delete next[formData.id];
      return next;
    });

    setFeedbackMessage('Alterações salvas com sucesso.');
    addToast('Alterações salvas com sucesso!', 'success', 3000);
    window.setTimeout(() => setFeedbackMessage(''), 2500);
  };

  const handleDelete = () => {
    if (!formData) {
      return;
    }

    const confirmed = window.confirm('Deseja mover este artigo para o lixo?');

    if (!confirmed) {
      return;
    }

    try {
      deleteArticle(formData.id);
      router.push('/admin/artigos');
    } catch (error) {
      addToast(error instanceof Error ? error.message : 'Sem permissão para excluir este artigo.', 'error', 3000);
    }
  };

  if (!isLoaded || !currentUser) {
    return <div className="p-6 text-sm text-gray-600">Carregando artigo...</div>;
  }

  if (!formData) {
    return (
      <div className="flex min-h-screen flex-col bg-gray-100 md:flex-row">
        <AdminSidebar />
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <div className="rounded-xl bg-white p-8 shadow-sm">
            <h1 className="text-2xl font-bold text-gray-900">Artigo não encontrado</h1>
            <p className="mt-2 text-gray-600">O artigo solicitado não existe ou já foi removido.</p>
            <Link href="/admin/artigos" className="mt-6 inline-flex rounded-lg bg-[#111111] px-4 py-2 font-semibold text-white transition hover:bg-[#2a2a2a]">Voltar para artigos</Link>
          </div>
        </main>
      </div>
    );
  }

  if (!canAccessArticle) {
    return (
      <div className="flex min-h-screen flex-col bg-gray-100 md:flex-row">
        <AdminSidebar />
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <div className="rounded-xl bg-white p-8 shadow-sm">
            <h1 className="text-2xl font-bold text-gray-900">Acesso negado</h1>
            <p className="mt-2 text-gray-600">Você só pode editar matérias próprias neste perfil.</p>
            <Link href="/admin/artigos" className="mt-6 inline-flex rounded-lg bg-[#111111] px-4 py-2 font-semibold text-white transition hover:bg-[#2a2a2a]">Voltar para artigos</Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-gray-100 md:flex-row">
      <AdminSidebar />

      <main className="flex-1 overflow-auto">
        <div className="sticky top-0 z-20 border-b border-gray-200 bg-white">
          <div className="flex flex-col gap-4 px-8 py-5 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center gap-4">
              <Link href="/admin/artigos" className="rounded-lg p-2 transition hover:bg-gray-100">
                <ArrowLeft className="h-6 w-6 text-gray-600" />
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Editar artigo</h1>
                <p className="text-sm text-gray-600">Atualize e salve a notícia selecionada.</p>
              </div>
            </div>
            {canDeleteArticle(currentUser, formData.author) && (
              <button type="button" onClick={handleDelete} className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-700">
                <Trash2 className="h-4 w-4" />
                Mover para o lixo
              </button>
            )}
          </div>
          {feedbackMessage && (
            <div className="flex items-center gap-2 bg-green-100 px-8 py-3 text-sm font-semibold text-green-700">
              <CheckCircle2 className="h-5 w-5" />
              {feedbackMessage}
            </div>
          )}
        </div>

        <div className="p-4 sm:p-6 lg:p-8">
          <div className="grid gap-8 xl:grid-cols-[minmax(0,2fr),360px]">
            <div className="space-y-6">
              <section className="rounded-xl bg-white p-6 shadow-sm">
                <h2 className="text-lg font-bold text-gray-900">Informações principais</h2>
                <div className="mt-5 space-y-5">
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-gray-900">Título</label>
                    <input type="text" name="title" value={formData.title} onChange={handleFieldChange} className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#FF796C] focus:outline-none" />
                  </div>
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-gray-900">Linha fina</label>
                    <input type="text" name="subtitle" value={formData.subtitle} onChange={handleFieldChange} className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#FF796C] focus:outline-none" />
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <label className="mb-2 block text-sm font-semibold text-gray-900">Categoria</label>
                      <select name="category" value={formData.category} onChange={handleFieldChange} className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#FF796C] focus:outline-none">
                        {categoryOptions.map((category) => (
                          <option key={category.id} value={category.slug}>{category.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="mb-2 block text-sm font-semibold text-gray-900">Autor</label>
                      <select
                        name="author"
                        value={formData.author}
                        onChange={handleFieldChange}
                        disabled={!canViewAllArticles(currentUser)}
                        className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#FF796C] focus:outline-none disabled:cursor-not-allowed disabled:bg-gray-100"
                      >
                        {canViewAllArticles(currentUser) ? (
                          users.filter((user) => user.status === 'ativo').map((user) => (
                            <option key={user.id} value={user.name}>{user.name}</option>
                          ))
                        ) : (
                          <option value={currentUser.name}>{currentUser.name}</option>
                        )}
                        {canViewAllArticles(currentUser) && (!users.some((user) => user.status === 'ativo') || !users.some((user) => user.name === formData.author)) && (
                          <option value={formData.author}>{formData.author}</option>
                        )}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-gray-900">Resumo</label>
                    <textarea name="excerpt" value={formData.excerpt} onChange={handleFieldChange} rows={4} className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#FF796C] focus:outline-none" />
                  </div>
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-gray-900">Local de publicação</label>
                    <select name="location" value={formData.location ?? brazilianLocations[0]} onChange={handleFieldChange} className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#FF796C] focus:outline-none">
                      {brazilianLocations.map((location) => (
                        <option key={location} value={location}>{location}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </section>

              <section className="rounded-xl bg-white p-6 shadow-sm">
                <div className="mb-4 flex items-center justify-between gap-4">
                  <div>
                    <h2 className="text-lg font-bold text-gray-900">Conteúdo</h2>
                    <p className="text-sm text-gray-500">Edite a notícia com a mesma formatação do cadastro.</p>
                  </div>
                  <div className="text-right text-sm text-gray-500">
                    <p>{wordCount} palavras</p>
                    <p>{readingTime} min de leitura</p>
                  </div>
                </div>
                <HtmlEditor
                  value={formData.content}
                  onChange={(content) => setDrafts((current) => ({ ...current, [formData.id]: { ...formData, content } }))}
                  minHeight={360}
                />
              </section>

              <ArticlePreviewPanel
                title={formData.title}
                subtitle={formData.subtitle}
                category={categoryOptions.find((category) => category.slug === formData.category)?.name ?? formData.category}
                author={formData.author}
                content={formData.content}
                images={mediaState.images}
                videos={mediaState.videos}
                location={formData.location}
                publishedAt={formData.publishedAt ?? formData.createdAt}
                lastUpdatedAt={formData.lastUpdatedAt ?? formData.updatedAt}
              />
            </div>

            <aside className="space-y-6">
              <section className="rounded-xl bg-white p-6 shadow-sm">
                <div className="mb-4">
                  <h2 className="text-lg font-bold text-gray-900">Mídia da matéria</h2>
                  <p className="mt-1 text-sm text-gray-500">Atualize imagens, vídeos e a imagem principal sem sair do painel.</p>
                </div>
                <ArticleMediaManager
                  initialImages={mediaState.images}
                  initialVideos={mediaState.videos}
                  initialPrimaryImage={mediaState.primaryImage}
                  title={formData.title || 'A notícia'}
                  onChange={handleMediaChange}
                />
              </section>

              <section className="rounded-xl bg-white p-6 shadow-sm">
                <h2 className="text-lg font-bold text-gray-900">Publicação</h2>
                <div className="mt-4 space-y-4">
                  <label className="flex items-start gap-3">
                    <input type="checkbox" name="featured" checked={formData.featured} onChange={handleFieldChange} className="mt-1 h-4 w-4 rounded border-gray-300 text-[#FF796C]" />
                    <span>
                      <span className="block font-semibold text-gray-900">Exibir no hero</span>
                      <span className="text-sm text-gray-500">Use para destacar a notícia na página inicial.</span>
                    </span>
                  </label>
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-gray-900">Status</label>
                    <select
                      name="status"
                      value={formData.status}
                      onChange={handleFieldChange}
                      disabled={!canPublishArticle(currentUser, formData.author)}
                      className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#FF796C] focus:outline-none disabled:cursor-not-allowed disabled:bg-gray-100"
                    >
                      <option value="rascunho">Rascunho</option>
                      <option value="agendado">Agendado</option>
                      <option value="publicado">Publicado</option>
                    </select>
                  </div>
                  {formData.status === 'agendado' && (
                    <div className="grid gap-3">
                      <input type="date" name="scheduledDate" value={formData.scheduledDate ?? ''} onChange={handleFieldChange} className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#FF796C] focus:outline-none" />
                      <input type="time" name="scheduledTime" value={formData.scheduledTime ?? ''} onChange={handleFieldChange} className="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-[#FF796C] focus:outline-none" />
                    </div>
                  )}
                </div>
              </section>

              <button type="button" onClick={handleSave} className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-3 text-sm font-bold text-white transition hover:bg-emerald-700">
                <Save className="h-4 w-4" />
                Salvar alterações
              </button>
            </aside>
          </div>
        </div>

        <ToastContainer toasts={toasts} removeToast={removeToast} />
      </main>
    </div>
  );
}
