-- SQL para criar a tabela compartilhada usada pelo portal de notícias
-- Execute no SQL Editor do Supabase do projeto real.

create table if not exists public.pz_news_articles (
  id text primary key,
  payload jsonb not null default '{}'::jsonb,
  deleted boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_pz_news_articles_updated_at
  on public.pz_news_articles (updated_at desc);

create index if not exists idx_pz_news_articles_deleted
  on public.pz_news_articles (deleted);

alter table public.pz_news_articles enable row level security;

-- Leitura pública: só artigos não deletados
create policy "public_read_non_deleted_articles"
  on public.pz_news_articles
  for select
  using (deleted = false);

-- Escrita do admin: permissivo para funcionar com a app atual sem auth do Supabase
create policy "admin_insert_articles"
  on public.pz_news_articles
  for insert
  with check (true);

create policy "admin_update_articles"
  on public.pz_news_articles
  for update
  using (true)
  with check (true);

create policy "admin_delete_articles"
  on public.pz_news_articles
  for delete
  using (true);

-- Opcional: manter updated_at em qualquer escrita
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_set_updated_at on public.pz_news_articles;
create trigger trg_set_updated_at
before update on public.pz_news_articles
for each row
execute function public.set_updated_at();
